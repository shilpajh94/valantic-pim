/**
 * Data Definitions.
 *
 * LICENSE
 *
 * This source file is subject to the GNU General Public License version 3 (GPLv3)
 * For the full copyright and license information, please view the LICENSE.md and gpl-3.0.txt
 * files that are distributed with this source code.
 *
 * @copyright  Copyright (c) 2016-2019 instride AG (https://www.instride.ch)
 * @license
 * https://github.com/instride/DataDefinitions/blob/master/gpl-3.0.txt GNU General Public License version 3 (GPLv3)
 */

pimcore.registerNS('pimcore.plugin.datadefinitions.import.panel');

pimcore.plugin.datadefinitions.import.panel = Class.create(coreshop.resource.panel, {
    layoutId: 'data_definitions_import_definition_panel',
    storeId: 'data_definitions_definitions',
    iconCls: 'data_definitions_icon_import_definition',
    type: 'definition',

    url: {
        add: '/admin/data_definitions/import_definitions/add',
        delete: '/admin/data_definitions/import_definitions/delete',
        get: '/admin/data_definitions/import_definitions/get'
    },

    routing: {
        add: null,
        delete: null,
        get: null
    },

    providers: [],
    cleaners: [],
    interpreters: [],
    setters: [],
    filters: [],
    runners: [],
    persisters: [],

    getDefaultGridConfiguration: function () {
        return {
            region: 'west',
            store: pimcore.globalmanager.get(this.storeId),
            columns: [
                {
                    text: 'ID',
                    dataIndex: 'id',
                    flex: 1,
                    renderer: this.getGridDisplayColumnRenderer
                },
                {
                    text: 'Name',
                    dataIndex: this.getDefaultGridDisplayColumnName(),
                    flex: 4,
                    renderer: this.getGridDisplayColumnRenderer
                }

            ],
            listeners: this.getTreeNodeListeners(),
            useArrows: true,
            autoScroll: true,
            animate: true,
            containerScroll: true,
            width: 200,
            split: true,
            tbar: this.getTopBar(),
            bbar: {
                items: [{
                    xtype: 'label',
                    text: '',
                    itemId: 'totalLabel'
                }, '->', {
                    iconCls: 'pimcore_icon_reload',
                    scale: 'small',
                    handler: function () {
                        this.grid.getStore().load();
                    }.bind(this)
                }]
            },
            hideHeaders: false
        };
    },

    getTitle: function () {
        return t('data_definitions_import_definitions');
    },

    initialize: function () {
        Ext.Ajax.request({
            url: '/admin/data_definitions/import_definitions/get-config',
            method: 'GET',
            success: function (result) {
                var config = Ext.decode(result.responseText);
                // Here weget provider, loader, interpreter  values in dropdown 
                this.providers = [];
                this.loaders = [];
                this.filters = [];
                this.interpreters = [];
                this.setters = [];
                this.cleaners = [];
                this.runners = [];
                this.persisters = [];

                config.providers.forEach(function (provider) {
                    this.providers.push([provider]);
                }.bind(this));

                config.loaders.forEach(function (loader) {
                    this.loaders.push([loader]);
                }.bind(this));

                config.filters.forEach(function (filter) {
                    this.filters.push([filter]);
                }.bind(this));

                config.interpreter.forEach(function (interpreter) {
                    this.interpreters.push([interpreter]);
                }.bind(this));

                config.setter.forEach(function (setter) {
                    this.setters.push([setter]);
                }.bind(this));

                config.cleaner.forEach(function (cleaner) {
                    this.cleaners.push([cleaner]);
                }.bind(this));

                config.runner.forEach(function (runner) {
                    this.runners.push([runner]);
                }.bind(this));

                config.persister.forEach(function (persister) {
                    this.persisters.push([persister]);
                }.bind(this));

                var providerStore = new Ext.data.ArrayStore({
                    data: this.providers,
                    fields: ['provider'],
                    idProperty: 'provider'
                });

                pimcore.globalmanager.add('importdefinitions_providers', providerStore);
                pimcore.globalmanager.add('data_definitions_providers', providerStore);

                var loaderStore = new Ext.data.ArrayStore({
                    data: this.loaders,
                    fields: ['loader'],
                    idProperty: 'loader'
                });

                pimcore.globalmanager.add('importdefinitions_loaders', loaderStore);
                pimcore.globalmanager.add('data_definitions_loaders', loaderStore);

                var filterStore = new Ext.data.ArrayStore({
                    data: this.filters,
                    fields: ['filter'],
                    idProperty: 'filter'
                });

                pimcore.globalmanager.add('importdefinitions_filters', filterStore);
                pimcore.globalmanager.add('data_definitions_filters', filterStore);

                var cleanersStore = new Ext.data.ArrayStore({
                    data: this.cleaners,
                    fields: ['cleaner'],
                    idProperty: 'cleaner'
                });

                pimcore.globalmanager.add('importdefinitions_cleaners', cleanersStore);
                pimcore.globalmanager.add('data_definitions_cleaners', cleanersStore);

                var interpretersStore = new Ext.data.ArrayStore({
                    data: this.interpreters,
                    fields: ['interpreter'],
                    idProperty: 'interpreter'
                });

                pimcore.globalmanager.add('importdefinitions_interpreters', interpretersStore);
                pimcore.globalmanager.add('data_definitions_interpreters', interpretersStore);

                var settersStore = new Ext.data.ArrayStore({
                    data: this.setters,
                    fields: ['setter'],
                    idProperty: 'setter'
                });

                pimcore.globalmanager.add('importdefinitions_setters', settersStore);
                pimcore.globalmanager.add('data_definitions_setters', settersStore);

                var runnersStore = new Ext.data.ArrayStore({
                    data: this.runners,
                    fields: ['runner'],
                    idProperty: 'runner'
                });

                pimcore.globalmanager.add('importdefinitions_runners', runnersStore);
                pimcore.globalmanager.add('data_definitions_runners', runnersStore);

                var persistersStore = new Ext.data.ArrayStore({
                    data: this.persisters,
                    fields: ['persister'],
                    idProperty: 'persister'
                });

                pimcore.globalmanager.add('importdefinitions_persisters', persistersStore);
                pimcore.globalmanager.add('data_definitions_persisters', persistersStore);

                pimcore.globalmanager.add('data_definitions_import_rule_conditions', config.import_rules.conditions);
                pimcore.globalmanager.add('data_definitions_import_rule_actions', config.import_rules.actions);

                this.getLayout();
            }.bind(this)
        });

        this.panels = [];
    },

    // function to override the function coreshop resource import panel
    addItemComplete: function (button, value, object) {
        
        var jsonData = {
            name: value
        };

        if (Ext.isFunction(this.prepareAdd)) {
            jsonData = this.prepareAdd(jsonData);
        }

        if (button === 'ok') {
            Ext.Ajax.request({
                url: this.url.add,
                jsonData: jsonData,
                method: 'post',
                success: function (response) {
                    var data = Ext.decode(response.responseText);

                    this.grid.getStore().reload();

                    this.refresh();

                    if (!data || !data.success) {
                        Ext.Msg.alert(t('data_definition_warning'), data.msg);
                    } else {
                        this.openItem(data.data);
                    }
                }.bind(this)
            });
        } else {
            //Ext.Msg.alert(t('No config file created'), t('User cancelled the process'));
        }
    },

    getItemClass: function () {
        return pimcore.plugin.datadefinitions.import.item;
    },
    
    // function to override the function coreshop resource import panel deleteItem
    deleteItem: function (record) {
            var me = this;
            Ext.MessageBox.show({
                title: 'Delete Definition',
                msg: 'Are you sure you want to delete? All the associated imported items will be deleted permanently.',
                buttons: Ext.MessageBox.OKCANCEL,
                icon: Ext.MessageBox.WARNING,
                fn: function(btn){
                    if(btn == 'ok')
                    {
                        Ext.Ajax.request({
                            url: me.url.delete,
                            method: 'DELETE',
                            params: {
                                id: record.id
                            },
                            success: function () {
                                me.grid.getStore().reload();
                
                                me.refresh();
                
                                if (me.panels[me.getPanelKey(record)]) {
                                    me.panels[me.getPanelKey(record)].destroy();
                                }
                
                            }.bind(me)
                        });
                    } else {
                        return;
                    }
                }
            });
    }
});
